3 mod — Starter (Vite + React + r3f)
Included:
- Model: public/models/bugatti_la_voiture.glb (the file you uploaded)
- SingleModelViewer component (src/SingleModelViewer.jsx) that loads the model from /models/bugatti_la_voiture.glb by default.

How to run:
1. Extract the ZIP.
2. In the project folder run:
   npm install
   npm run dev
3. Open the local dev URL shown by Vite (usually http://localhost:5173)

Notes:
- The bundled GLB is placed in public/models/ so it's served at /models/bugatti_la_voiture.glb.
- You can also test by clicking "رفع موديل" in the page and uploading another .glb/.gltf file (temporary preview).
- If you prefer Tailwind styling, I can update the project to include a Tailwind setup.

